import { RouteObject } from 'react-router-dom';
import HomePage from '../pages/home/page';
import TarefasPage from '../pages/tarefas/page';
import ResidenciasPage from '../pages/residencias/page';
import FieisPage from '../pages/fieis/page';
import VisitasPage from '../pages/visitas/page';
import NotFound from '../pages/NotFound';

const routes: RouteObject[] = [
  {
    path: '/',
    element: <HomePage />,
  },
  {
    path: '/residencias',
    element: <ResidenciasPage />,
  },
  {
    path: '/fieis',
    element: <FieisPage />,
  },
  {
    path: '/visitas',
    element: <VisitasPage />,
  },
  {
    path: '/tarefas',
    element: <TarefasPage />,
  },
  {
    path: '*',
    element: <NotFound />,
  },
];

export default routes;