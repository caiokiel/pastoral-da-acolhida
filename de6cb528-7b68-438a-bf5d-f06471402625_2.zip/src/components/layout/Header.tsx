
import { useState } from 'react';

const Header = () => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showProfile, setShowProfile] = useState(false);

  const notifications = [
    { id: 1, message: 'Nova visita agendada para hoje', time: '5 min atrás', type: 'info' },
    { id: 2, message: 'Tarefa atribuída: Visita ao Sr. João', time: '1 hora atrás', type: 'task' },
    { id: 3, message: 'Novo fiel cadastrado', time: '2 horas atrás', type: 'success' },
  ];

  return (
    <header className="bg-white border-b border-gray-200 h-16 fixed top-0 right-0 left-64 z-30">
      <div className="flex items-center justify-between h-full px-6">
        {/* Search Bar */}
        <div className="flex-1 max-w-md">
          <div className="relative">
            <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
            <input
              type="text"
              placeholder="Buscar fiéis, residências..."
              className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent font-nunito text-sm"
            />
          </div>
        </div>

        {/* Right Section */}
        <div className="flex items-center space-x-4">
          {/* Quick Actions */}
          <button className="p-2 text-gray-600 hover:text-orange-600 hover:bg-orange-50 rounded-lg transition-colors">
            <i className="ri-add-line text-lg"></i>
          </button>

          {/* Notifications */}
          <div className="relative">
            <button
              onClick={() => setShowNotifications(!showNotifications)}
              className="p-2 text-gray-600 hover:text-orange-600 hover:bg-orange-50 rounded-lg transition-colors relative"
            >
              <i className="ri-notification-line text-lg"></i>
              <span className="absolute -top-1 -right-1 w-5 h-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                3
              </span>
            </button>

            {showNotifications && (
              <div className="absolute right-0 top-12 w-80 bg-white rounded-lg shadow-lg border border-gray-200 py-2 z-50">
                <div className="px-4 py-2 border-b border-gray-100">
                  <h3 className="font-nunito font-semibold text-gray-800">Notificações</h3>
                </div>
                <div className="max-h-64 overflow-y-auto">
                  {notifications.map((notification) => (
                    <div key={notification.id} className="px-4 py-3 hover:bg-gray-50 border-b border-gray-50 last:border-b-0">
                      <p className="font-nunito text-sm text-gray-800">{notification.message}</p>
                      <p className="text-xs text-gray-500 mt-1">{notification.time}</p>
                    </div>
                  ))}
                </div>
                <div className="px-4 py-2 border-t border-gray-100">
                  <button className="text-orange-600 text-sm font-nunito font-medium hover:text-orange-700">
                    Ver todas as notificações
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Profile */}
          <div className="relative">
            <button
              onClick={() => setShowProfile(!showProfile)}
              className="flex items-center space-x-2 p-2 rounded-lg hover:bg-gray-50 transition-colors"
            >
              <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center">
                <i className="ri-user-line text-white text-sm"></i>
              </div>
              <span className="font-nunito font-medium text-gray-700 text-sm">Padre João</span>
              <i className="ri-arrow-down-s-line text-gray-400"></i>
            </button>

            {showProfile && (
              <div className="absolute right-0 top-12 w-48 bg-white rounded-lg shadow-lg border border-gray-200 py-2 z-50">
                <a href="#" className="flex items-center space-x-2 px-4 py-2 hover:bg-gray-50 text-gray-700">
                  <i className="ri-user-line"></i>
                  <span className="font-nunito text-sm">Meu Perfil</span>
                </a>
                <a href="#" className="flex items-center space-x-2 px-4 py-2 hover:bg-gray-50 text-gray-700">
                  <i className="ri-settings-line"></i>
                  <span className="font-nunito text-sm">Configurações</span>
                </a>
                <hr className="my-2" />
                <a href="#" className="flex items-center space-x-2 px-4 py-2 hover:bg-gray-50 text-red-600">
                  <i className="ri-logout-box-line"></i>
                  <span className="font-nunito text-sm">Sair</span>
                </a>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;
