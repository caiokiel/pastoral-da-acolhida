
import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';

const Sidebar = () => {
  const [isCollapsed, setIsCollapsed] = useState(false);
  const location = useLocation();

  const menuItems = [
    { icon: 'ri-dashboard-line', label: 'Dashboard', path: '/' },
    { icon: 'ri-home-4-line', label: 'Residências', path: '/residencias' },
    { icon: 'ri-user-line', label: 'Fiéis', path: '/fieis' },
    { icon: 'ri-map-pin-line', label: 'Visitas', path: '/visitas' },
    { icon: 'ri-task-line', label: 'Tarefas', path: '/tarefas' },
    { icon: 'ri-calendar-line', label: 'Agenda', path: '/agenda' },
    { icon: 'ri-team-line', label: 'Pastorais', path: '/pastorais' },
    { icon: 'ri-user-settings-line', label: 'Agentes', path: '/agentes' },
    { icon: 'ri-settings-line', label: 'Configurações', path: '/configuracoes' },
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <div className={`bg-white border-r border-gray-200 h-screen fixed left-0 top-0 z-40 transition-all duration-300 ${isCollapsed ? 'w-16' : 'w-64'}`}>
      {/* Logo */}
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          {!isCollapsed && (
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-gradient-to-br from-orange-400 to-orange-600 rounded-full flex items-center justify-center">
                <i className="ri-church-line text-white text-lg"></i>
              </div>
              <div>
                <h1 className="font-nunito font-bold text-gray-800 text-sm">Pastoral da Acolhida</h1>
                <p className="text-xs text-gray-500">São José Operário</p>
              </div>
            </div>
          )}
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors"
          >
            <i className={`ri-menu-${isCollapsed ? 'unfold' : 'fold'}-line text-gray-600`}></i>
          </button>
        </div>
      </div>

      {/* Menu Items */}
      <nav className="p-2 space-y-1">
        {menuItems.map((item) => (
          <Link
            key={item.path}
            to={item.path}
            className={`flex items-center space-x-3 px-3 py-2.5 rounded-lg transition-all duration-200 group ${
              isActive(item.path)
                ? 'bg-orange-50 text-orange-600 border-r-2 border-orange-600'
                : 'text-gray-600 hover:bg-gray-50 hover:text-gray-800'
            }`}
          >
            <i className={`${item.icon} text-lg ${isCollapsed ? 'mx-auto' : ''}`}></i>
            {!isCollapsed && (
              <span className="font-nunito font-medium text-sm whitespace-nowrap">{item.label}</span>
            )}
          </Link>
        ))}
      </nav>

      {/* User Profile */}
      {!isCollapsed && (
        <div className="absolute bottom-4 left-4 right-4">
          <div className="bg-gray-50 rounded-lg p-3">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-orange-500 rounded-full flex items-center justify-center">
                <i className="ri-user-line text-white text-sm"></i>
              </div>
              <div className="flex-1 min-w-0">
                <p className="font-nunito font-medium text-sm text-gray-800 truncate">Padre João</p>
                <p className="text-xs text-gray-500">Administrador</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Sidebar;
