
import Layout from '../../components/layout/Layout';

const HomePage = () => {
  const stats = [
    { label: 'Total de Residências', value: '1,247', icon: 'ri-home-4-line', color: 'bg-blue-500' },
    { label: 'Fiéis Cadastrados', value: '3,891', icon: 'ri-user-line', color: 'bg-green-500' },
    { label: 'Visitas Este Mês', value: '156', icon: 'ri-map-pin-line', color: 'bg-orange-500' },
    { label: 'Tarefas Pendentes', value: '23', icon: 'ri-task-line', color: 'bg-red-500' },
  ];

  const recentVisits = [
    { id: 1, family: 'Família Silva', address: 'Rua das Flores, 123', agent: 'Maria Santos', date: '2024-01-15', status: 'Concluída' },
    { id: 2, family: 'Família Oliveira', address: 'Av. Principal, 456', agent: 'João Pedro', date: '2024-01-14', status: 'Concluída' },
    { id: 3, family: 'Família Costa', address: 'Rua da Igreja, 789', agent: 'Ana Maria', date: '2024-01-13', status: 'Pendente' },
  ];

  const upcomingTasks = [
    { id: 1, title: 'Visita ao Sr. José (doente)', assignee: 'Padre João', priority: 'Alta', dueDate: 'Hoje' },
    { id: 2, title: 'Entrega de jornal comunitário', assignee: 'Equipe Pascom', priority: 'Média', dueDate: 'Amanhã' },
    { id: 3, title: 'Cadastro nova família', assignee: 'Maria Santos', priority: 'Baixa', dueDate: '18/01' },
  ];

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-bold text-gray-800 font-nunito">Dashboard</h1>
          <p className="text-gray-600 font-nunito">Bem-vindo ao sistema da Pastoral da Acolhida</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((stat, index) => (
            <div key={index} className="bg-white rounded-lg p-6 shadow-sm border border-gray-200">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600 font-nunito">{stat.label}</p>
                  <p className="text-2xl font-bold text-gray-800 font-nunito mt-1">{stat.value}</p>
                </div>
                <div className={`w-12 h-12 ${stat.color} rounded-lg flex items-center justify-center`}>
                  <i className={`${stat.icon} text-white text-xl`}></i>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Recent Visits */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold text-gray-800 font-nunito">Visitas Recentes</h2>
                <button className="text-orange-600 text-sm font-medium hover:text-orange-700 font-nunito">
                  Ver todas
                </button>
              </div>
            </div>
            <div className="p-6">
              <div className="space-y-4">
                {recentVisits.map((visit) => (
                  <div key={visit.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-800 font-nunito">{visit.family}</h3>
                      <p className="text-sm text-gray-600 font-nunito">{visit.address}</p>
                      <p className="text-xs text-gray-500 font-nunito mt-1">Por: {visit.agent}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-gray-600 font-nunito">{visit.date}</p>
                      <span className={`inline-block px-2 py-1 text-xs rounded-full font-nunito ${
                        visit.status === 'Concluída' 
                          ? 'bg-green-100 text-green-800' 
                          : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {visit.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Upcoming Tasks */}
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-semibold text-gray-800 font-nunito">Próximas Tarefas</h2>
                <button className="text-orange-600 text-sm font-medium hover:text-orange-700 font-nunito">
                  Ver kanban
                </button>
              </div>
            </div>
            <div className="p-6">
              <div className="space-y-4">
                {upcomingTasks.map((task) => (
                  <div key={task.id} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div className="flex-1">
                      <h3 className="font-medium text-gray-800 font-nunito">{task.title}</h3>
                      <p className="text-sm text-gray-600 font-nunito">Responsável: {task.assignee}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm text-gray-600 font-nunito">{task.dueDate}</p>
                      <span className={`inline-block px-2 py-1 text-xs rounded-full font-nunito ${
                        task.priority === 'Alta' 
                          ? 'bg-red-100 text-red-800' 
                          : task.priority === 'Média'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-green-100 text-green-800'
                      }`}>
                        {task.priority}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h2 className="text-lg font-semibold text-gray-800 font-nunito mb-4">Ações Rápidas</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <button className="flex flex-col items-center p-4 bg-orange-50 rounded-lg hover:bg-orange-100 transition-colors">
              <i className="ri-home-add-line text-2xl text-orange-600 mb-2"></i>
              <span className="text-sm font-medium text-gray-800 font-nunito">Nova Residência</span>
            </button>
            <button className="flex flex-col items-center p-4 bg-blue-50 rounded-lg hover:bg-blue-100 transition-colors">
              <i className="ri-user-add-line text-2xl text-blue-600 mb-2"></i>
              <span className="text-sm font-medium text-gray-800 font-nunito">Cadastrar Fiel</span>
            </button>
            <button className="flex flex-col items-center p-4 bg-green-50 rounded-lg hover:bg-green-100 transition-colors">
              <i className="ri-map-pin-add-line text-2xl text-green-600 mb-2"></i>
              <span className="text-sm font-medium text-gray-800 font-nunito">Agendar Visita</span>
            </button>
            <button className="flex flex-col items-center p-4 bg-purple-50 rounded-lg hover:bg-purple-100 transition-colors">
              <i className="ri-task-line text-2xl text-purple-600 mb-2"></i>
              <span className="text-sm font-medium text-gray-800 font-nunito">Nova Tarefa</span>
            </button>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default HomePage;
