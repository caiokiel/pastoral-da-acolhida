
import { useState } from 'react';
import Layout from '../../components/layout/Layout';

interface Visita {
  id: number;
  residenciaId: number;
  endereco: string;
  responsavel: string;
  agentePastoral: string;
  dataVisita: string;
  horaVisita: string;
  tipoVisita: string;
  motivo: string;
  observacoes: string;
  status: 'agendada' | 'realizada' | 'cancelada' | 'reagendada';
  proximaVisita?: string;
}

const VisitasPage = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState('todas');
  const [viewMode, setViewMode] = useState<'list' | 'calendar'>('list');

  const visitas: Visita[] = [
    {
      id: 1,
      residenciaId: 1,
      endereco: 'Rua das Flores, 123',
      responsavel: 'Maria Silva',
      agentePastoral: 'Padre João',
      dataVisita: '2024-01-20',
      horaVisita: '14:00',
      tipoVisita: 'Pastoral',
      motivo: 'Visita de acolhida',
      observacoes: 'Família receptiva, interessada em participar das atividades',
      status: 'agendada',
      proximaVisita: '2024-02-20'
    },
    {
      id: 2,
      residenciaId: 2,
      endereco: 'Av. Principal, 456',
      responsavel: 'João Santos',
      agentePastoral: 'Irmã Maria',
      dataVisita: '2024-01-18',
      horaVisita: '16:30',
      tipoVisita: 'Sacramental',
      motivo: 'Preparação para batismo',
      observacoes: 'Casal interessado em batizar o filho',
      status: 'realizada'
    },
    {
      id: 3,
      residenciaId: 3,
      endereco: 'Rua da Paz, 789',
      responsavel: 'Ana Costa',
      agentePastoral: 'Diácono Pedro',
      dataVisita: '2024-01-15',
      horaVisita: '10:00',
      tipoVisita: 'Assistencial',
      motivo: 'Visita a enfermo',
      observacoes: 'Sr. José está acamado, família precisa de apoio espiritual',
      status: 'realizada',
      proximaVisita: '2024-01-25'
    },
    {
      id: 4,
      residenciaId: 1,
      endereco: 'Rua das Flores, 123',
      responsavel: 'Maria Silva',
      agentePastoral: 'Agente Pastoral Ana',
      dataVisita: '2024-01-22',
      horaVisita: '19:00',
      tipoVisita: 'Evangelização',
      motivo: 'Entrega do jornal paroquial',
      observacoes: 'Levar exemplares do último boletim',
      status: 'agendada'
    }
  ];

  const filteredVisitas = visitas.filter(visita => {
    const lowerSearch = searchTerm.toLowerCase();
    const matchesSearch =
      visita.endereco.toLowerCase().includes(lowerSearch) ||
      visita.responsavel.toLowerCase().includes(lowerSearch) ||
      visita.agentePastoral.toLowerCase().includes(lowerSearch) ||
      visita.motivo.toLowerCase().includes(lowerSearch);

    const matchesFilter = selectedFilter === 'todas' || visita.status === selectedFilter;

    return matchesSearch && matchesFilter;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'agendada':
        return 'bg-blue-100 text-blue-800';
      case 'realizada':
        return 'bg-green-100 text-green-800';
      case 'cancelada':
        return 'bg-red-100 text-red-800';
      case 'reagendada':
        return 'bg-yellow-100 text-yellow-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'agendada':
        return 'Agendada';
      case 'realizada':
        return 'Realizada';
      case 'cancelada':
        return 'Cancelada';
      case 'reagendada':
        return 'Reagendada';
      default:
        return status;
    }
  };

  const getTipoColor = (tipo: string) => {
    switch (tipo) {
      case 'Pastoral':
        return 'bg-purple-100 text-purple-800';
      case 'Sacramental':
        return 'bg-blue-100 text-blue-800';
      case 'Assistencial':
        return 'bg-green-100 text-green-800';
      case 'Evangelização':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  // Helper to safely parse dates (prevents crashes on invalid dates)
  const safeParseDate = (dateStr?: string) => {
    if (!dateStr) return null;
    const date = new Date(dateStr);
    return isNaN(date.getTime()) ? null : date;
  };

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 font-nunito">Visitas</h1>
            <p className="text-gray-600 font-nunito">Gerencie as visitas pastorais às residências</p>
          </div>
          <div className="flex space-x-3">
            <div className="flex bg-gray-100 rounded-lg p-1">
              <button
                onClick={() => setViewMode('list')}
                className={`px-3 py-1 rounded-md text-sm font-medium transition-colors font-nunito whitespace-nowrap cursor-pointer ${
                  viewMode === 'list' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-600'
                }`}
              >
                <i className="ri-list-check mr-1"></i>
                Lista
              </button>
              <button
                onClick={() => setViewMode('calendar')}
                className={`px-3 py-1 rounded-md text-sm font-medium transition-colors font-nunito whitespace-nowrap cursor-pointer ${
                  viewMode === 'calendar' ? 'bg-white text-gray-900 shadow-sm' : 'text-gray-600'
                }`}
              >
                <i className="ri-calendar-line mr-1"></i>
                Calendário
              </button>
            </div>
            <button
              onClick={() => setShowModal(true)}
              className="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition-colors font-nunito font-medium whitespace-nowrap cursor-pointer"
            >
              <i className="ri-add-line mr-2"></i>
              Nova Visita
            </button>
          </div>
        </div>

        {/* Filters and Search */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                <input
                  type="text"
                  placeholder="Buscar por endereço, responsável, agente ou motivo..."
                  value={searchTerm}
                  onChange={e => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent font-nunito text-sm"
                />
              </div>
            </div>
            <div className="flex gap-2 flex-wrap">
              {['todas', 'agendada', 'realizada', 'reagendada', 'cancelada'].map(filter => (
                <button
                  key={filter}
                  onClick={() => setSelectedFilter(filter)}
                  className={`px-4 py-2 rounded-lg font-nunito font-medium text-sm whitespace-nowrap cursor-pointer transition-colors ${
                    selectedFilter === filter
                      ? 'bg-orange-600 text-white'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {filter === 'todas' ? 'Todas' : getStatusText(filter)}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <i className="ri-calendar-check-line text-blue-600 text-xl"></i>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600 font-nunito">Agendadas</p>
                <p className="text-2xl font-bold text-gray-900 font-nunito">
                  {visitas.filter(v => v.status === 'agendada').length}
                </p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <i className="ri-checkbox-circle-line text-green-600 text-xl"></i>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600 font-nunito">Realizadas</p>
                <p className="text-2xl font-bold text-gray-900 font-nunito">
                  {visitas.filter(v => v.status === 'realizada').length}
                </p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                <i className="ri-map-pin-line text-orange-600 text-xl"></i>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600 font-nunito">Total de Visitas</p>
                <p className="text-2xl font-bold text-gray-900 font-nunito">{visitas.length}</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                <i className="ri-calendar-todo-line text-purple-600 text-xl"></i>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600 font-nunito">Esta Semana</p>
                <p className="text-2xl font-bold text-gray-900 font-nunito">
                  {visitas.filter(v => {
                    const visitaDate = safeParseDate(v.dataVisita);
                    if (!visitaDate) return false;
                    const hoje = new Date();
                    const startOfWeek = new Date(hoje);
                    startOfWeek.setDate(hoje.getDate() - hoje.getDay()); // domingo
                    startOfWeek.setHours(0, 0, 0, 0);
                    const endOfWeek = new Date(startOfWeek);
                    endOfWeek.setDate(startOfWeek.getDate() + 6);
                    endOfWeek.setHours(23, 59, 59, 999);
                    return visitaDate >= startOfWeek && visitaDate <= endOfWeek;
                  }).length}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Visitas List */}
        {viewMode === 'list' && (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200">
            <div className="p-6 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900 font-nunito">Lista de Visitas</h2>
            </div>
            <div className="divide-y divide-gray-200">
              {filteredVisitas.map(visita => (
                <div key={visita.id} className="p-6 hover:bg-gray-50">
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="text-lg font-medium text-gray-900 font-nunito">{visita.endereco}</h3>
                        <span
                          className={`inline-flex px-2 py-1 text-xs font-medium rounded-full font-nunito ${getStatusColor(
                            visita.status
                          )}`}
                        >
                          {getStatusText(visita.status)}
                        </span>
                        <span
                          className={`inline-flex px-2 py-1 text-xs font-medium rounded-full font-nunito ${getTipoColor(
                            visita.tipoVisita
                          )}`}
                        >
                          {visita.tipoVisita}
                        </span>
                      </div>
                      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm text-gray-600">
                        <div className="flex items-center">
                          <i className="ri-user-line mr-2 text-gray-400"></i>
                          <span className="font-nunito">{visita.responsavel}</span>
                        </div>
                        <div className="flex items-center">
                          <i className="ri-user-star-line mr-2 text-gray-400"></i>
                          <span className="font-nunito">{visita.agentePastoral}</span>
                        </div>
                        <div className="flex items-center">
                          <i className="ri-calendar-line mr-2 text-gray-400"></i>
                          <span className="font-nunito">
                            {new Date(visita.dataVisita).toLocaleDateString('pt-BR')} às {visita.horaVisita}
                          </span>
                        </div>
                        <div className="flex items-center">
                          <i className="ri-chat-3-line mr-2 text-gray-400"></i>
                          <span className="font-nunito">{visita.motivo}</span>
                        </div>
                      </div>
                      {visita.observacoes && (
                        <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                          <p className="text-sm text-gray-700 font-nunito">{visita.observacoes}</p>
                        </div>
                      )}
                      {visita.proximaVisita && (
                        <div className="mt-2 flex items-center text-sm text-orange-600">
                          <i className="ri-calendar-schedule-line mr-2"></i>
                          <span className="font-nunito">
                            Próxima visita: {new Date(visita.proximaVisita).toLocaleDateString('pt-BR')}
                          </span>
                        </div>
                      )}
                    </div>
                    <div className="flex space-x-2 ml-4">
                      <button className="text-orange-600 hover:text-orange-900 cursor-pointer">
                        <i className="ri-eye-line"></i>
                      </button>
                      <button className="text-blue-600 hover:text-blue-900 cursor-pointer">
                        <i className="ri-edit-line"></i>
                      </button>
                      <button className="text-green-600 hover:text-green-900 cursor-pointer">
                        <i className="ri-calendar-schedule-line"></i>
                      </button>
                      {visita.status === 'agendada' && (
                        <button className="text-purple-600 hover:text-purple-900 cursor-pointer">
                          <i className="ri-check-line"></i>
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Calendar View */}
        {viewMode === 'calendar' && (
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="text-center py-12">
              <i className="ri-calendar-line text-6xl text-gray-300 mb-4"></i>
              <h3 className="text-lg font-medium text-gray-900 font-nunito mb-2">
                Visualização em Calendário
              </h3>
              <p className="text-gray-600 font-nunito">
                Esta funcionalidade será implementada em breve
              </p>
            </div>
          </div>
        )}

        {/* Modal */}
        {showModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-4xl mx-4 max-h-[90vh] overflow-y-auto">
              <div className="p-6 border-b border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 font-nunito">Nova Visita</h3>
              </div>
              <div className="p-6 space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 font-nunito mb-1">
                      Residência
                    </label>
                    <div className="relative">
                      <button className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-nunito text-sm text-left bg-white pr-8">
                        Selecione uma residência
                      </button>
                      <i className="ri-arrow-down-s-line absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 font-nunito mb-1">
                      Agente Pastoral
                    </label>
                    <div className="relative">
                      <button className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-nunito text-sm text-left bg-white pr-8">
                        Selecione um agente
                      </button>
                      <i className="ri-arrow-down-s-line absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 font-nunito mb-1">
                      Data da Visita
                    </label>
                    <input
                      type="date"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-nunito text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 font-nunito mb-1">
                      Horário
                    </label>
                    <input
                      type="time"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-nunito text-sm"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 font-nunito mb-1">
                      Tipo de Visita
                    </label>
                    <div className="relative">
                      <button className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-nunito text-sm text-left bg-white pr-8">
                        Selecione o tipo
                      </button>
                      <i className="ri-arrow-down-s-line absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 font-nunito mb-1">
                      Status
                    </label>
                    <div className="relative">
                      <button className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-nunito text-sm text-left bg-white pr-8">
                        Agendada
                      </button>
                      <i className="ri-arrow-down-s-line absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                    </div>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 font-nunito mb-1">
                    Motivo da Visita
                  </label>
                  <input
                    type="text"
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-nunito text-sm"
                    placeholder="Descreva o motivo da visita"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 font-nunito mb-1">
                    Observações
                  </label>
                  <textarea
                    rows={4}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-nunito text-sm"
                    placeholder="Informações adicionais sobre a visita..."
                  ></textarea>
                </div>

                <div>
                  <label className="flex items-center">
                    <input
                      type="checkbox"
                      className="rounded border-gray-300 text-orange-600 focus:ring-orange-500"
                    />
                    <span className="ml-2 text-sm text-gray-700 font-nunito">
                      Agendar próxima visita automaticamente
                    </span>
                  </label>
                </div>
              </div>
              <div className="p-6 border-t border-gray-200 flex justify-end space-x-3">
                <button
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors font-nunito font-medium whitespace-nowrap cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors font-nunito font-medium whitespace-nowrap cursor-pointer"
                >
                  Agendar Visita
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default VisitasPage;
