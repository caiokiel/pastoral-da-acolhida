
import { useState } from 'react';
import Layout from '../../components/layout/Layout';

const TarefasPage = () => {
  const [selectedColumn, setSelectedColumn] = useState<string | null>(null);

  const columns = [
    { id: 'todo', title: 'À Fazer', color: 'bg-gray-100', count: 8 },
    { id: 'doing', title: 'Fazendo', color: 'bg-blue-100', count: 3 },
    { id: 'done', title: 'Feita', color: 'bg-green-100', count: 12 },
    { id: 'archived', title: 'Arquivada', color: 'bg-gray-200', count: 25 },
  ];

  const tasks = {
    todo: [
      { id: 1, title: 'Visita ao Sr. José (doente)', assignee: 'Padre João', priority: 'Alta', dueDate: 'Hoje', type: 'Visita Pastoral' },
      { id: 2, title: 'Entrega de jornal comunitário', assignee: 'Equipe Pascom', priority: 'Média', dueDate: 'Amanhã', type: 'Comunicação' },
      { id: 3, title: 'Cadastro nova família - Rua das Flores', assignee: 'Maria Santos', priority: 'Baixa', dueDate: '18/01', type: 'Cadastro' },
      { id: 4, title: 'Benção de casa nova', assignee: 'Padre João', priority: 'Média', dueDate: '20/01', type: 'Sacramento' },
    ],
    doing: [
      { id: 5, title: 'Visita à Família Silva', assignee: 'Ana Maria', priority: 'Média', dueDate: 'Hoje', type: 'Visita Domiciliar' },
      { id: 6, title: 'Organizar lista de batizandos', assignee: 'Catequese', priority: 'Alta', dueDate: 'Hoje', type: 'Sacramento' },
    ],
    done: [
      { id: 7, title: 'Visita à Dona Maria (idosa)', assignee: 'João Pedro', priority: 'Alta', dueDate: '14/01', type: 'Visita Pastoral' },
      { id: 8, title: 'Cadastro Família Oliveira', assignee: 'Maria Santos', priority: 'Média', dueDate: '13/01', type: 'Cadastro' },
    ],
    archived: [
      { id: 9, title: 'Distribuição de cestas básicas', assignee: 'Pastoral Social', priority: 'Alta', dueDate: '10/01', type: 'Ação Social' },
    ],
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'Alta': return 'bg-red-100 text-red-800';
      case 'Média': return 'bg-yellow-100 text-yellow-800';
      case 'Baixa': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'Visita Pastoral': return 'ri-heart-line';
      case 'Visita Domiciliar': return 'ri-home-heart-line';
      case 'Sacramento': return 'ri-church-line';
      case 'Cadastro': return 'ri-user-add-line';
      case 'Comunicação': return 'ri-newspaper-line';
      case 'Ação Social': return 'ri-hand-heart-line';
      default: return 'ri-task-line';
    }
  };

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-800 font-nunito">Kanban de Tarefas</h1>
            <p className="text-gray-600 font-nunito">Gerencie suas atividades pastorais</p>
          </div>
          <button className="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition-colors font-nunito font-medium whitespace-nowrap">
            <i className="ri-add-line mr-2"></i>
            Nova Tarefa
          </button>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center space-x-2">
              <label className="text-sm font-medium text-gray-700 font-nunito">Filtrar por:</label>
              <select className="border border-gray-200 rounded-lg px-3 py-1.5 text-sm font-nunito pr-8">
                <option>Todos os tipos</option>
                <option>Visita Pastoral</option>
                <option>Visita Domiciliar</option>
                <option>Sacramento</option>
                <option>Cadastro</option>
                <option>Comunicação</option>
                <option>Ação Social</option>
              </select>
            </div>
            <div className="flex items-center space-x-2">
              <label className="text-sm font-medium text-gray-700 font-nunito">Responsável:</label>
              <select className="border border-gray-200 rounded-lg px-3 py-1.5 text-sm font-nunito pr-8">
                <option>Todos</option>
                <option>Padre João</option>
                <option>Maria Santos</option>
                <option>Ana Maria</option>
                <option>João Pedro</option>
                <option>Equipe Pascom</option>
              </select>
            </div>
            <div className="flex items-center space-x-2">
              <label className="text-sm font-medium text-gray-700 font-nunito">Prioridade:</label>
              <select className="border border-gray-200 rounded-lg px-3 py-1.5 text-sm font-nunito pr-8">
                <option>Todas</option>
                <option>Alta</option>
                <option>Média</option>
                <option>Baixa</option>
              </select>
            </div>
          </div>
        </div>

        {/* Kanban Board */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {columns.map((column) => (
            <div key={column.id} className="bg-white rounded-lg shadow-sm border border-gray-200">
              {/* Column Header */}
              <div className={`${column.color} p-4 rounded-t-lg border-b border-gray-200`}>
                <div className="flex items-center justify-between">
                  <h3 className="font-semibold text-gray-800 font-nunito">{column.title}</h3>
                  <span className="bg-white text-gray-600 text-xs px-2 py-1 rounded-full font-nunito">
                    {column.count}
                  </span>
                </div>
              </div>

              {/* Tasks */}
              <div className="p-4 space-y-3 min-h-96">
                {tasks[column.id as keyof typeof tasks]?.map((task) => (
                  <div
                    key={task.id}
                    className="bg-gray-50 rounded-lg p-4 border border-gray-100 hover:shadow-md transition-shadow cursor-pointer"
                  >
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center space-x-2">
                        <i className={`${getTypeIcon(task.type)} text-orange-600`}></i>
                        <span className={`px-2 py-1 text-xs rounded-full font-nunito ${getPriorityColor(task.priority)}`}>
                          {task.priority}
                        </span>
                      </div>
                      <button className="text-gray-400 hover:text-gray-600">
                        <i className="ri-more-line"></i>
                      </button>
                    </div>

                    <h4 className="font-medium text-gray-800 font-nunito mb-2 text-sm leading-tight">
                      {task.title}
                    </h4>

                    <div className="space-y-2">
                      <div className="flex items-center text-xs text-gray-600 font-nunito">
                        <i className="ri-user-line mr-1"></i>
                        {task.assignee}
                      </div>
                      <div className="flex items-center text-xs text-gray-600 font-nunito">
                        <i className="ri-calendar-line mr-1"></i>
                        {task.dueDate}
                      </div>
                      <div className="flex items-center text-xs text-gray-500 font-nunito">
                        <i className="ri-bookmark-line mr-1"></i>
                        {task.type}
                      </div>
                    </div>
                  </div>
                ))}

                {/* Add Task Button */}
                <button className="w-full p-3 border-2 border-dashed border-gray-300 rounded-lg text-gray-500 hover:border-orange-300 hover:text-orange-600 transition-colors font-nunito text-sm">
                  <i className="ri-add-line mr-1"></i>
                  Adicionar tarefa
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </Layout>
  );
};

export default TarefasPage;
