import { useState } from 'react';
import Layout from '../../components/layout/Layout';

interface Residencia {
  id: number;
  endereco: string;
  numero: string;
  bairro: string;
  cep: string;
  responsavel: string;
  telefone: string;
  totalFieis: number;
  ultimaVisita: string;
  status: 'ativa' | 'inativa' | 'pendente';
}

const ResidenciasPage = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [showModal, setShowModal] = useState(false);
  const [selectedFilter, setSelectedFilter] = useState('todas');

  const residencias: Residencia[] = [
    {
      id: 1,
      endereco: 'Rua das Flores, 123',
      numero: '123',
      bairro: 'Centro',
      cep: '12345-678',
      responsavel: 'Maria Silva',
      telefone: '(11) 99999-9999',
      totalFieis: 4,
      ultimaVisita: '2024-01-15',
      status: 'ativa'
    },
    {
      id: 2,
      endereco: 'Av. Principal, 456',
      numero: '456',
      bairro: 'Vila Nova',
      cep: '12345-679',
      responsavel: 'João Santos',
      telefone: '(11) 88888-8888',
      totalFieis: 3,
      ultimaVisita: '2024-01-10',
      status: 'ativa'
    },
    {
      id: 3,
      endereco: 'Rua da Paz, 789',
      numero: '789',
      bairro: 'Jardim Esperança',
      cep: '12345-680',
      responsavel: 'Ana Costa',
      telefone: '(11) 77777-7777',
      totalFieis: 2,
      ultimaVisita: '2023-12-20',
      status: 'pendente'
    }
  ];

  const filteredResidencias = residencias.filter(residencia => {
    const matchesSearch = residencia.endereco.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         residencia.responsavel.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         residencia.bairro.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesFilter = selectedFilter === 'todas' || residencia.status === selectedFilter;
    
    return matchesSearch && matchesFilter;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'ativa': return 'bg-green-100 text-green-800';
      case 'inativa': return 'bg-red-100 text-red-800';
      case 'pendente': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case 'ativa': return 'Ativa';
      case 'inativa': return 'Inativa';
      case 'pendente': return 'Pendente';
      default: return status;
    }
  };

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900 font-nunito">Residências</h1>
            <p className="text-gray-600 font-nunito">Gerencie o cadastro de residências do território paroquial</p>
          </div>
          <button
            onClick={() => setShowModal(true)}
            className="bg-orange-600 text-white px-4 py-2 rounded-lg hover:bg-orange-700 transition-colors font-nunito font-medium whitespace-nowrap cursor-pointer"
          >
            <i className="ri-add-line mr-2"></i>
            Nova Residência
          </button>
        </div>

        {/* Filters and Search */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <i className="ri-search-line absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400"></i>
                <input
                  type="text"
                  placeholder="Buscar por endereço, responsável ou bairro..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="w-full pl-10 pr-4 py-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 focus:border-transparent font-nunito text-sm"
                />
              </div>
            </div>
            <div className="flex gap-2">
              {['todas', 'ativa', 'pendente', 'inativa'].map((filter) => (
                <button
                  key={filter}
                  onClick={() => setSelectedFilter(filter)}
                  className={`px-4 py-2 rounded-lg font-nunito font-medium text-sm whitespace-nowrap cursor-pointer transition-colors ${
                    selectedFilter === filter
                      ? 'bg-orange-600 text-white'
                      : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }`}
                >
                  {filter === 'todas' ? 'Todas' : getStatusText(filter)}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                <i className="ri-home-4-line text-blue-600 text-xl"></i>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600 font-nunito">Total de Residências</p>
                <p className="text-2xl font-bold text-gray-900 font-nunito">{residencias.length}</p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                <i className="ri-checkbox-circle-line text-green-600 text-xl"></i>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600 font-nunito">Ativas</p>
                <p className="text-2xl font-bold text-gray-900 font-nunito">
                  {residencias.filter(r => r.status === 'ativa').length}
                </p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-yellow-100 rounded-lg flex items-center justify-center">
                <i className="ri-time-line text-yellow-600 text-xl"></i>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600 font-nunito">Pendentes</p>
                <p className="text-2xl font-bold text-gray-900 font-nunito">
                  {residencias.filter(r => r.status === 'pendente').length}
                </p>
              </div>
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
            <div className="flex items-center">
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center">
                <i className="ri-user-line text-orange-600 text-xl"></i>
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600 font-nunito">Total de Fiéis</p>
                <p className="text-2xl font-bold text-gray-900 font-nunito">
                  {residencias.reduce((total, r) => total + r.totalFieis, 0)}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Residências List */}
        <div className="bg-white rounded-lg shadow-sm border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-lg font-semibold text-gray-900 font-nunito">Lista de Residências</h2>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider font-nunito">
                    Endereço
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider font-nunito">
                    Responsável
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider font-nunito">
                    Telefone
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider font-nunito">
                    Fiéis
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider font-nunito">
                    Última Visita
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider font-nunito">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider font-nunito">
                    Ações
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredResidencias.map((residencia) => (
                  <tr key={residencia.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div>
                        <div className="text-sm font-medium text-gray-900 font-nunito">{residencia.endereco}</div>
                        <div className="text-sm text-gray-500 font-nunito">{residencia.bairro} - {residencia.cep}</div>
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900 font-nunito">{residencia.responsavel}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900 font-nunito">{residencia.telefone}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900 font-nunito">{residencia.totalFieis}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-900 font-nunito">
                        {new Date(residencia.ultimaVisita).toLocaleDateString('pt-BR')}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-2 py-1 text-xs font-medium rounded-full font-nunito ${getStatusColor(residencia.status)}`}>
                        {getStatusText(residencia.status)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <div className="flex space-x-2">
                        <button className="text-orange-600 hover:text-orange-900 cursor-pointer">
                          <i className="ri-eye-line"></i>
                        </button>
                        <button className="text-blue-600 hover:text-blue-900 cursor-pointer">
                          <i className="ri-edit-line"></i>
                        </button>
                        <button className="text-green-600 hover:text-green-900 cursor-pointer">
                          <i className="ri-map-pin-add-line"></i>
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Modal */}
        {showModal && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-lg shadow-xl w-full max-w-2xl mx-4">
              <div className="p-6 border-b border-gray-200">
                <h3 className="text-lg font-semibold text-gray-900 font-nunito">Nova Residência</h3>
              </div>
              <div className="p-6 space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 font-nunito mb-1">
                      Endereço
                    </label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-nunito text-sm"
                      placeholder="Rua, Avenida..."
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 font-nunito mb-1">
                      Número
                    </label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-nunito text-sm"
                      placeholder="123"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 font-nunito mb-1">
                      Bairro
                    </label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-nunito text-sm"
                      placeholder="Nome do bairro"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 font-nunito mb-1">
                      CEP
                    </label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-nunito text-sm"
                      placeholder="12345-678"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 font-nunito mb-1">
                      Responsável
                    </label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-nunito text-sm"
                      placeholder="Nome do responsável"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 font-nunito mb-1">
                      Telefone
                    </label>
                    <input
                      type="text"
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-nunito text-sm"
                      placeholder="(11) 99999-9999"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 font-nunito mb-1">
                    Observações
                  </label>
                  <textarea
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-orange-500 font-nunito text-sm"
                    placeholder="Informações adicionais sobre a residência..."
                  ></textarea>
                </div>
              </div>
              <div className="p-6 border-t border-gray-200 flex justify-end space-x-3">
                <button
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors font-nunito font-medium whitespace-nowrap cursor-pointer"
                >
                  Cancelar
                </button>
                <button
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 bg-orange-600 text-white rounded-lg hover:bg-orange-700 transition-colors font-nunito font-medium whitespace-nowrap cursor-pointer"
                >
                  Salvar Residência
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </Layout>
  );
};

export default ResidenciasPage;